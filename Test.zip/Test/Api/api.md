# Api

desenvolvendo para testar `api's`. Será utilizado como **:type**: `request spec`. Para utilizar todos os teste para utilizar os teste de requisição

```sh
rails g rspec:request customers
```

mas também vamos precisar de uma gem como **matcher**, para verificar o contéudo dentro do **json**. Para instalar você pode usar: `gem 'rspec-json_expectations'`

```ruby
# spec/spec_helper
require 'rspec/json_expectations' # em muitos casos essa etapa pode ser pulada
```

Vamos verificar como vai ficar:

```ruby
require 'rail_helper'

Rspec.describe 'Customers', type: :request do
  describe 'GET /customers' do
    it '200' do
      get customers_path
      expect(response).to have_http_status(200)
    end

    it 'index' do
      get '/customers.json'
      expect(response).to have_http_status(200)
      expect(response.body).to include_json([
        id: /\d/,
        name: 'teste',
        email: 'teste@gmail.com'
      ])
  end

  it 'show' do
    get './customers/1.json'
    expect(response).to have_http_status(200)

    # matchers do rspec
    expect(responde.body).to include_json(
      id: /\d/, # any integer
      name: (be_kind_of String),
      email: (be_kind_of String)
    )
  end

  it 'post' do
    # post
    customer = create(:member)
    login_as(member, scope: :member)

    headers = { "ACCEPT" => "appliction/json" }

    params = attributes_for(:customers)
    post './customers', params: { customer: params }, headers: headers

    expect(respose.body).to include_json(
      id: /\d/,
      name: params[:name),
      email: params[:email]
    )
  end

  it 'patch/put' do
    customer = create(:member)
    login_as(member, scope: :member)

    headers = { "ACCEPT" => "appliction/json" }

    customer = Customer.first
    customer.name += 'Atualizado'

    patch './customers/1.json', params: { customer: customer.attributes_for }, headers: headers

    expect(respose.body).to include_json(
      id: /\d/,
      name: customer.name),
      email: customer.email
    )
  end

  it 'delete' do
    member = create(:member)
    login_as(member, scope: :member)

    headers = { "ACCEPT" => "appliction/json" }

    customer = Customer.first

    # verify delete
    expect{ delete "/customers/#{customer.id}.json", headers: headers }.to change(Customer, :count).by(-1)
    expect(response).to have_http_status(204)
  end
end
```

## Rspec puro com Json

> Sem precisar do walterlink

```ruby
it "show - pure" do
  get '/customers/1.json'
  response_body = JSON.parse(response.body)
  expect(response_body['id']).to  eq(1)
  expect(response_body['name']).to  be_kind_of(String)
  expect(response_body['email']).to  be_kind_of(String)
end
```

## Json Schema

> verificar se o formato do json está no meio desejado

validação por `json-schema`

```json
// por exemplo
{
  "title": "Person",
  "type": "object",
  "properties": {
    "firstName": {
      "type": "string"
    },
    "lastName": {
      "type": "string"
    },
    "age": {
      "description": "Age in years",
      "type": "integer",
      "minimum": 0
    }
  },
  "required": ["firstName", "lastName"]
}
```

a gem para isso:

```sh
gem install 'json-matchers'
```

```ruby
# spec/spec_helper.rb

# JSON SCHEMA
require "json_mathcer/rspec"
```

vamos criar um arquivo dentro de `support`: `spec/support/api/schemas/` e dentro dessa pasta `modelo.json`

```json
// spec/support/api/schemas/customer.json
{
  "type": "object",
  "properties": {
    "customer" : {
      "required": ["id", "name", "email"],
      "properties": {
        "id": { "type": "integer" },
        "email": { "type": "string" },
        "name": { "type": "string" },
        "create_at": { "type": "string", "format": "date-time" },
        "update_at": { "type": "string", "format": "date-time" }
      }
    }
  }
}
```

para usar

```ruby
describe "GET /posts" do
  it 'json schema' do
    get '/customer/1.json', format: :json

    expect(response.status).to eq 200
    expect(response).to match_response_schema("customer")  
  end
end
```