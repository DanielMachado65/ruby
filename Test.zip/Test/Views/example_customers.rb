require 'rails_helper'
require_relative 'support/new_customer_form.rb'

Rspec.feature 'Customers', type: :feature, js: true do
  it 'Visit index page' do
    visit(customers_path)
    page.save_screeshot('screenshot.png')
    expect(page).to have_current_path(customers_path)
  end

  it 'Ajax' do
    visit(customers_path)
    click_link('Add Message')

    # se demorar mais tempo
    expect(page).to have_content('Yes!')
  end

  it 'Find' do
    visit(customers_path)
    click_link('Add Message')

    # Verificar o caminho
    expect(find('#my_div').find('h1')).to have_content('Yes!')
  end

  it 'Crete a Customer' do
    member = create(:member)
    login_as(member, scope: :user)

    # visitar a url
    visit(new_customers_path)

    # preencher esse formulario, com label
    fill_in 'Name',	with: Faker::Name.name
    fill_in 'Email',	with: Faker::Internet.email
    fill_in 'Address',	with: Faker::Address.street_address

    # clickar no botao
    click_button('Create Customer')

    # verificar se a pagina conseguiu criar o contéudo
    expect(page).to have_content('Customer was successfully created.')
  end

  it 'Create a Customer - Page Object Pattern' do
    # instancia de html
    new_customer_form = NewCustomerForm.new
    new_customer_form.login.visit_page.fill_in_with(
      name: Faker::Name.name,
      email: Faker::Internet.email,
      address: Faker::Address.street_address
    ).submit

    # verificar se a pagina conseguiu criar o contéudo
    expect(page).to have_content('Customer was successfully created.')
  end
end
