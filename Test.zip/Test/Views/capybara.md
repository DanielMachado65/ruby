# [Capybara](https://gist.github.com/tomas-stefano/6652111)

**Teste de aceitação**: é uma fase do processo de teste de caixa-preta é realizado num sistema antes da sua disponibilização

> Métodos de mais altos níveis, como o usuário real interaje com a sua aplicação.

O capybara, já vem pré-configurado, quando é utilizado o `rails 5.1`.

```sh
# command
rails g rspec:feature <feature_name>

# running
rails g rspec:feature costumers
```

## DSL

Como é que utilizado conforme a navegação

### `Visit`

navegar pelas páginas

```ruby
visit('/project')
# or helper
visit()
```

para com o teste

```ruby
require 'rails_helper'

RSpec.feature 'Customers', type: :feature do
  it 'Visit index page' do
    # verificar se a url lá de cima tenha o determinado valor
    visit(customers_path)

    # page, variável da página
    expect(page).to have_current_path(customers_path)
  end
end
```

---

## Debugging

vamos analisar com o debugging. Analisar a página

```ruby
# saida do que está sendo acessado
print page.html

# salvou o html dentro de um arquivo temporário
save_and_open_page

# salvar um screen shot (para salvar uma imagem, do momento)
save_screenshot('screenshot.png')

# provalmente ele vai dar um erro, porque o vagrant não está configurado.
```

Configurando o screenshot:

1. se você está numa máquina virtual, não tem como utilizar.
2. você deverá colocar dentro do projeto, `js: true`
3. instalar o Chromium: `apt-get install chromium-chromedriver`
4. instalar no `gemfile`
   1. gem 'selenium-webdriver'
   2. gem 'chromedrive-helper' -> apenas se você estiver trabalhando dentro da máquina virtual
5. configurar as linhas dentro do `spec_helper.rb`:

```ruby
Capybara.register_driver :chorme do |app|
  Capybara::Selenium::Driver.new app, brower: :chorme,
    options:
    Selenium::WebDriver::Chrome::Options.new(args: %w[headless disable-gpu])
end

Capybara.javascript_driver = :chorme
```

6. ignorar a chamadas localhost:

```ruby
VCR.configure do |config|
  config.cassette_library_dir = 'spec/fixtures/vcr_cassettes'
  config.hook_into :webmock
  config.configure_rspec_medata!
  config.filter_sensitive_data('<API-URL>') { 'https...'}

  # add
  config.ignore_localhost = true
end
```

```ruby
RSpec.feature 'Customers', type: :feature, js: true do
  it 'Visit index page' do
    # verificar se a url lá de cima tenha o determinado valor
    visit(customers_path)

    # page, variável da página
    expect(page).to have_current_path(customers_path)
  end
end
```

### Matcher

podemos ter algum matcher:

| Comando                                    | Descrição                          |
| ------------------------------------------ | ---------------------------------- |
| `become_closed(option={})`                 | verificar se a janela vai fechar   |
| `have_button(locator, option={})`          | verificar se tem um botão          |
| `have_checked_field(locator, option={})`   | verificar se o radio button        |
| `have_unchecked_field(locator, option={})` | verificar o radio button ñ marcado |
| `have_css(css, option={})`                 | para css                           |
| `have_current_path(path, option={})`       | se o caminho atual                 |
| `have_field(locator, option={})`           | para campos                        |
| `have_link(locator, option={})`            | para links                         |
| `have_select(locator, option={})`          | para input do tipo select          |
| `have_selector(*args)`                     | seletor                            |
| `have_table(locator, option={})`           | para tabelas                       |
| `have_text(*args)`                         | para texto                         |
| `have_title(title, option={})`             | para titulos                       |
| `have_xpath(xpath, option={})`             | para **xpath**                     |
| `match_css(css, option={})`                | para validador de css              |
| `match_selector(*args)`                    | para validação do selector         |
| `match_xpath(xpath, option={})`            | para validação do **xpath**        |

---

Para a gente conseguir o capivará com o `devise`. Vamos ter que utilizar, outra configuração conhecido:

```ruby
# spec/rails_helper.rb

config.include Warden::Test::Helpers
```

vamos poder criar um usuário com:

```ruby
user = FactoryBot.create(:user)
login_as(user, scope: :user)
```

## Clicks/Links

Vamos simular os clicks do usuário.

```ruby
require 'rails_helper'

Rspec.feature 'Customers', type: :feature, js: true do
  it 'Visit index page' do
    visit(customers_path)
    page.save_screeshot('screenshot.png')
    expect(page).to have_current_path(customers_path)
  end

  it 'Crete a Customer' do
    member = create(:member)
    login_as(member, scope: :user)

    # visitar a url
    visit(new_customers_path)

    # preencher esse formulario, com label
    fill_in 'Name',	with: Faker::Name.name
    fill_in 'Email',	with: Faker::Internet.email
    fill_in 'Address',	with: Faker::Address.street_address

    # clickar no botao
    click_button('Create Customer')

    # verificar se a pagina conseguiu criar o contéudo
    expect(page).to have_content('Customer was successfully created.')
  end
end
```

## Find

Podemos verificar se determinado elemento tem determinado contéudo

```ruby
find_field('First Name').value
find_field(id: 'my_field').value

# links
find_link('Hello', visible: :all).visible?
find_link(class: [:some_class, :some_other_class], visible: :all).visible?

# buttons
find_button('Send').click
find_button(value: '1234').click

# xpath
find(:xpath, ".//table/tr").click
find('#overla').find("h1").click

# interations for all elements
all('a').each { |a| a[:href] }
```

## xPath

Uma linguagem de consulta para selecionar nós de um documento.

> buscar a por um caminho de elementos

```ruby
page.hax_xpath?('.//table/tr')

# or

page.has_selector?(:xpath, './/table/tr')
```

podemos entender como:

```xpath
/html/body[@class='dashboard premios index ']/header/div[@class='header-menu-bar']/div[@class='container']/div[@class='row']/div[@class='col-xs-12']/ul[@class='main-nav']/li[4]/a[@class='main-nav__item main-nav--rewards']
```

## Ajax

Quando a gente está trabalhando com ajax, ele espera 2 segundos para conseguir aguardar a informação na tela.

- Se você quiser, podemos deixar que a configuração de demora seja maior

```ruby
# spec/spec_helper.rb
# ... rest code ...

Capybara.default_max_wait_time = 5
```
