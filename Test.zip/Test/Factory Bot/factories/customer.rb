FactoryBot.define do
  factory :customer do
    name 'daniel'
    email 'teste@gmail.com'
  end
end