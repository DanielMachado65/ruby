# Factory Bot

para instalar

```sh
gem install 'factory_bot_rails'
```

configurar o no `rais_helper`

```ruby
Rspec.configure do |config|
  #factory Bot
  config.include FactoryBot::Syntax::Methods
end
```

para configurar o **lint**, podemos ter:

```ruby
# before all tests
# rspec_helper
config.before(:suite) do
  FactoryBot.lint
end
```

## Definindo Factories

por padrão o direto deve ser `test/factories` ou `spec/factories` se você tiver usando **rspec**. Porque caso você queira alterar:

```ruby
config.generators do |g|
  g.factory_bot dir: '../custom/dir/for/'
end
```

Vamos definir a fabrica de dados

```ruby
# /spec/factories/customer.rb

FactoryBot.define do
  factory :customer do
    name 'Jackson'
    email 'jack@gmail.com'
  end
end
```

você pode utilizar através de dois modos: {`build(:name)` or `create(:name)`}. Lembrando que o **build** não vai salvar

```ruby
require 'rails_helper'

RSpec.describe Customer, type: :model do
  it 'Create a Customer' do
    customer = create(:customer)
    expect(customer.full_name).to eq('Sr. Jackson Pires')
  end
end
```

---

## Gem Faker  gem 'faker'


vamos definir para gerar alguns atributos **dinâmicos**.

```sh
# gera dados falsos
gem install 'faker'
```

vamos usar dentro do **rspec**

```ruby
FactoryBot.define do
  factory :customer do
    name Fake::Name.name
    email Fake::Internet.email
  end
end
```

### Sobreescrever atributos

```ruby
  # vamos sobre escrever com os atributos
  it '#full_name' do
    customer = create(:customer, name: "Nome")
    expect(customer.full_name).to eq('Nome')
  end
```

### Sinomios

vamos dar o sinonimo

```ruby
FactoryBot.define do
  factory :customer, aliases: [:user, :father] do
  end
end
```

### Herança

podemos utilizar novas fabricas a partir de um modelo

```ruby
FactoryBot.define do
  factory :customer, aliases: [:user, :father] do
    name Faker::Name.name
    email Faker::Internet.email

    # podemos utilizar como herança para criar
    # create(:customer_vip)
    # para determinar outros atributos do seu objeto
    factory :customer_vip do
      vip true
      days_for_pay 30
    end

    factory :customer_default do
      vip false
      days_for_pay 15
    end
  end
end
```

### Atributos Dinâmcos

sempre quando você for utilizar um atributo dinamico, passe-o entre blocos

```ruby
FactoryBot.define do
  factory :customer, aliases: [:user, :father] do
    name { Faker::Name.name }
    email { Faker::Internet.email }

    # quando você tenta
    nome Faker::Name.name
    email { email + "@email" }
  end
end
```

### Attributes_for

trazer apenas os atributos gerados em formado do hash. Ajuda para fazer teste de _API_.

```ruby
it 'Attributes_for' do
  attrs = attributes_for(:customer)
end
```

### Transient Attributes

> atributos passageiros

a ideia é não fazer existir os atributos no momento do teste. Quando você coloca a `!` - você obriga a alteração do elemento

```ruby
FactoryBot.define do
  # sem ter alteração real
  transient do
    upcaded false
  end

  # ...

  # after
  after(:create) do |customer, evaluator|
    customer.name.upcase! if evaluator.upcaded
  end
end

# spec/models/customer_spec.rb
it 'Atributo transiet' do
  customer = create(:customer_default, upcased: true)

  # só verificar se a condição foi atendida
  expect(customer.name.upcase).to eq(customer.name)
end
```

### Traits

> Agrupar os atributos e formar novas fabricas, ajuda quando é uma fabrica herdada

```ruby
FactoryBot.define do
  # sortei
  gender ['m', 'f'].sample

  trait :male do
    gender 'm'
  end

  trait :vip do
    vip true
    days_for_pay 30
  end

  factory :customer_male, traits: [:male]
  factory :customer_male_vip, traits: [:male, :vip]
end

# spec/model/customer_spec.rb

it 'Cliente Masculino' do
  customer = create(:customer_vip, :male)
  expect(customer.gender).to eq('m')
end

```

quando você quer herdar você só transforma a factory em `trait`.

### Callbacks

> vamos falar sobre as possiveis callback

| Callback        | Descrição                  |
| --------------- | -------------------------- |
| after(:create)  | depois de criado           |
| after(:build)   | depois de ser create/build |
| before(:create) | antes de ser criado        |

### Sequences

> quando você quer sequencia

```ruby
sequence(:email) { |n| "meu_email#{n}@gmail.com" }
sequence(:email, 'a') { |n| "meu_email#{n}@gmail.com" }
sequence(:email, 23 ) { |n| "meu_email#{n}@gmail.com" } # string.next - ex: 'a'.next |> output: 'b'
```

### Associação

#### _belongs_to_

```ruby
FactoryBot.define do
  factory :order do
    sequence(:description) { |n| "Pedido número #{n}" }
    customer
    # vai instanciar se já tiver uma outra spec
  end
end


# rspec/models/order_spec.rb
require 'rails_helper'

RSpec.describe Order, type: :model do
  it 'Tem 1 pedido' do
    order = create(:order)
    expect(order.customer).to be_kind_of(Customer)
  end
end
```

porém você também pode sobreescrever o atributo o **Customer**

```ruby
# rspec/models/order_spec.rb
RSpec.describe Order, type: :model do
  it 'Criar um customer' do
    customer = create(:customer)
    order = create(:order, customer: customer)

    expect(order.customer).to be_kind_of(Customer)
  end
end

# você também pode sobreescrever a factory
FactoryBot.define do
  factory :order do
    # associação direta
    association :customer, factory: :customer
  end
end
```

#### _has_many_

```ruby
FactoryBot.define do
  factory :customer do
    transient do
      # vai criar 3 pedidos por default
      qtt_orders 3
    end

    # quando criar um cliente com pedido
    trait :with_orders do
      after(:create) do |customer, evaluator|
        create_list(:order, evaluator.qtt_orders, customer: customer)
      end
    end
  end
end
```

para verificar:

```ruby
Rspec.descripe Customer, type: :model do
  it 'has_many' do
    customer = create(:customer, :with_orders)
    # customer = create(:customer, :with_orders, qtt_orders: 5)

    expect(customer.orders.count).to eq(3)
  end

end
```

### Create List

> quando precisar de vários modelos

```ruby
# rspec/models/order_spec.rb
RSpec.describe Order, type: :model do
  it 'Criar [3] pedidos' do
    # você consegue sobreescrever os atributos ainda
    orders = create_list(:order, 3, description: '..')
    expect(order.count).to eq(3)
  end
end
```

você também pode ter: **build_list**.

- `create_pair` -> cria dois elementos `customer = create_pair(:order)`
- `attributes_for_list`: extrai atributos de terminado objeto
- `build_stubbed`: cria um objeto falso
- `build_stubbed_list`: cria uma lista de objetos falsos

## Webmock

> stubbing de requisições de http

iremos fazer um chamada irreal da requisição. Fazendo assim a desabilitar as requisições

```ruby
# spec_helper.rb -> header
require 'webmock/rspec'

Rspec.configure do
# ...
```

fazer uma requisição stub

```ruby
# :any -> methods http
stub_request(:any, "www.example.com")

# or more detail
stub_request(:get, "https://jsonplaceholder.typicode.com/post/2").with(headers: {'Accept' => '*/*', 'Accept-Encoding' => 'gzip;q=1.0,deflate;'}).to_return(status: 200, body: "", headers: {})
```

### VCr

> gravar as interações do seus teste

```sh
gem install 'vcr'
```

configurar:

```ruby
# rails_helper.rb
VCR.configure do |config|
  config.cassete_library_dir = 'fixtures/vcr_cassettes'
  config.hook_info :webmock
end
```

como usar:

```ruby
VCR.use_cassette("nome") do
  response = HTTParty.get("https://jsonplaceholder.typicode.com/posts/2")
  content_type = response.header['content-type']
end
```

podemos configurar com os __metadados__:

```ruby
config.configure_rspec_metadata!
```

agora podemos utiliza:

```ruby
it 'content-type', :vcr do
  response = HTTParty.get('https://jsonplaceholder.typicode.com/posts/2')
  content_type = response.headers['content-type']
  expect(content_type).to match(/application\/json/) 
end
```

mas você pode indicar o cassete:

```ruby
it 'content-type', vcr: { cassette_name: 'jsonplaceholder/json'} do
  # ...
end
```

