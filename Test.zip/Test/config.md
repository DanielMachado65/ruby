# Config

## Settup your database

Preparar para os teste 

```sh
rake db:test:prepare # descuidadamente 

rake db:test:clone_structure # preferido

rake db:migrate RAILS_ENV=test m
```