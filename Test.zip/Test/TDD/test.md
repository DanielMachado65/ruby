# Tdd

> Get started

Para executar vamos rodar usando `rspec`, usado como:

| Termo   | Descrição                                        |
| ------- | ------------------------------------------------ |
| spec    | arquivo onde que vai ficar os testes             |
| `rspec` | comando                                          |
| `_spec` | sufixo que precisa ter nos **arquivos de teste** |

```sh
# não precisa da subpasta, porém é interessante para organização
|> spec
|----- calculator
|--------- calculator_spec.rb (teste que vai ser da classe)
```

## Comandos

- ### Describre

> descrever os nossos textes

```ruby
describe 'texto' do

end
# ou para procurar dentro de lib a classe
require 'calculator'

describe Calculator do

end
```

e para rodar:

```sh
rspec
```

agora vamos criar um arquivo em `lib`

```ruby
# lib/calculator.rb
class Calculator

end
```

Podemos definir o que está acontecendo em seguida:

```ruby
describe Calculator, 'Sobre a calculadora' do
  ...
end
```

podemos separar por herança (aninhados):

```ruby
describe ClassePai do
  describe Classfilha do
    # ... o mais interno vence
  end
end
```

- ### It, Specify, Example

> usa o it para dizer que teste que será feito

```ruby
require 'calculator'

describe Calculator do
  # vai funcionar como se tivesse somando
  it 'sum method for 2 numbers' do
    cal = Calculator.new
    result = cal.sum(5, 7)

    # verificar se ela é igual
    expect(result).to eq(11)
  end
end
```

dentro da classe `Calculator`:

```ruby
class Calculator
  def sum(a, b)
    return (a + b).to_i
  end
end
```

**Lembrano**: que Specify e Example são apenas para a leitura

- ### Context

> Quando você vai fazer teste, você agrupe por método, ou ação, então para ser comum entre recursos, você pode agrupar

```ruby
# spec/calculator/calculator_spec.rb

describe Calculator do
  context 'use sum method for 2 numbers' do
    it 'with positive numbers' do
      calc = Calculator.new
      expect(calc.sum(5,7)).to eq(12)
    end
    it 'with negative numbers' do
      calc = Calculator.new
      expect(calc.sum(-5,7)).to eq(2)
    end
  end
end
```

vamos refatorar com o seguinte proposito

- `#`: métodos de instâncias
- `.`: métodos de classe

```ruby
...
context '#sum' do
  it 'with positive numbers' do
    ...
  end
end
```

- ### Subject

> em todos os casos, precisou instanciar a classe que estava trabalhando dentro do código
> para fazer a referência da **classe** é com o `subject`

```ruby
# vamos trabalhar com o contexto
# spec/calculator/calculator_spec.rb

describe Calculator do
  # vamos instanciar para que seja outro nome
  subject(:calc) { described_class.new() }

  context 'use sum method for 2 numbers' do
    it 'with positive numbers' do
      expect(subject.sum(5,7)).to eq(12)
    end
    it 'with negative numbers' do
      expect(calc.sum(-5,7)).to eq(2)
    end
  end
end
```

pode ser que você dê uma expressão:

```ruby
describe 'Classe Calculadora' do
  subject(:calc) { Calculador.new() }
end
```

- ### Xit

> se você quiser deixar pendente

```ruby
# se colocar o corpo do obrigatorio, você pode deixar como pedente.
describe Calculator do
  xit 'with negative numbers' do
    expect(subject.sum(5,7)).to eq(12)
  end

  # ou

  it 'context without body'
end
```

- ### Matchers

| Matcher                          | Descrição                              |
| -------------------------------- | -------------------------------------- |
| `expect().to`                    | será igual à                           |
| `expect().not_to`                | não será igual à                       |
| `be`/`equal`                     | vai verificar com o objeto             |
| `eql`/`eq`                       | vai verificar o contéudo(_valor_)      |
| `be_odd`                         | impar                                  |
| `be_even`                        | par                                    |
| `be_truthy`                      | ser verdadeiro                         |
| `be_falsey`                      | ser falso                              |
| `be_nil`                         | verificar se ela é vazia               |
| `be_between(min, max).inclusive` | verificar o intervalo                  |
| `be_between(min, max).exclusive` | verificar está fora do intervalo       |
| `match(/regex/)`                 | verificar com o regex                  |
| `start_with`                     | verificar se começa                    |
| `end_with`                       | verificar se tem no começo             |
| **Classes**                      |                                        |
| `be_instance_of`                 | verificar se ele é uma instancia       |
| `be_kind_of`                     | verificar se pode ser vindo de herança |
| `respond_to`                     | permite que utilize responde o método  |
| `be_a`/`be_an`                   | vai ser igual à `be_instance_of`       |
| `have_attribute`                 | verificar se tem um atributo           |
| `(:string_starting_with("j"))`   | vai começar com o tipo                 |

```ruby
describe "Matcher de Comparação" do
  it '#equal' do
    x = 'ruby'
    y = 'ruby'

    # testa o objeto
    expect(x).not_to be(y)
  end
end
```
