# BDD

podemos escrever com a _gema_ do rails `bdd` ou com o `cumbuber`

> Behave Driven Deselopment

O desenvolimento guiado para comportamento. A principal motivação é especficar os examplos de como vai funcionar o software.

```ruby
Feature: alerta de recebimento
  In order: para comprar um produto indisponivel no momento
  As a: cliente do site
  I Want: ser notificado quando um produto voltar a ficar disponivel
  Scenario: receber notificação
    Given: usuario esta logado
    And: usuario esta cadastrado no site
    When: usuario confirma o recebimento do alerta
    Then: alerta é criado para envio do email
```

com a `gem`:

```ruby
# spec/features/search_spec.rb
context 'Searching' do
  it 'Result is found' do
    Given 'I am on the search page' do
      visit '/search'
      expect(page).to have_content('Search')
    end

    When 'I search something' do
      fill_in 'Search' with: 'John'
      click_button 'Go'
    end

    Then 'I should see the word result' do
      expect(page).to have_content('Result')
    end
  end
end

# for running
# rspec spec/features/search_spec.rb
```
