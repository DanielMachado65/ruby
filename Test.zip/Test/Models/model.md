# Model

```sh
# generate category
rails g model Category description

# generate product
rails g model Product description price:decimal category:references
```

gerar a partir de um `rspec`

```sh
rails g rspec:model product
```

## Regras

1. quando instanciado com atributos válidos, deverá ser válido
2. validação devem ser testadas
3. métodos de classe e instância devem executar corretamente

