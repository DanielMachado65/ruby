# Intro

Vamos seguir usando o padrão `xUnit`, de onde que vai vir os padrões de teste:

> Padrão de `xUnit`. Para conseguir utilizar dos padrões para o desenvolvimento de teste em 4 fases

1. setup: quando você coloca `sut` (o que está sendo setado)
2. exercice: quando você intereje com o que está sendo exericitado
3. verify: parte de verificação, verificar o comportamento
4. teardown: coloca o sistema no estado antes do que ele já foi executado, finalizar todos os serviços

## Comandos

para executar com os comandos necessários, você pode deixar dentro do `.rspec`: 

```rspec
--require spec_helper
--format documentation 
```

configuração do rspec: `spec_helper`.

### Especificar 

* Por __titulo__ de fucionalidade:

```sh
# -e, vai carregar apenas um teste
rspec spec/calculator/calculator_spec.rb -e 'with positive numbers'
```

* Por __linha__ de funcionalidade

```sh
# pode rodar para identificar qual linha que dá
rspec spec/calcultator/calculator_spec.rb:15
```
